chrome.runtime.onInstalled.addListener(async ({reason}) => {
  const data = await chrome.storage.local.get("prompts");
  if (!Array.isArray(data.prompts)) await chrome.storage.local.set({prompts:[]});
  if (reason === "install") chrome.runtime.openOptionsPage();
});
chrome.action.onClicked.addListener(() => chrome.runtime.openOptionsPage());
