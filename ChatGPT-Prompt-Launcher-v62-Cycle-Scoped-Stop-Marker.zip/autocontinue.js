/* Auto-Continue: independent from Prompt Launcher v46's unmodified content.js.
   The entire interface lives in a shadow root, invisible to legacy page-wide
   button/label queries used by the original favicon state detector. */
(() => {
  'use strict';
  if (window.__plAutoContinueInstalled) return;
  window.__plAutoContinueInstalled = true;
  const KEY = 'plAutoContinueSettings';
  const defaults = {prompt:'Continue working toward the original assignment. Review progress and remaining tasks, and make substantive progress before stopping.', cycles:50, minutes:60, stop:'AUTOCONTINUE_COMPLETE'};
  const delay = ms => new Promise(r => setTimeout(r,ms));
  const editor = () => document.querySelector('#prompt-textarea,div[contenteditable="true"][data-lexical-editor="true"],div[contenteditable="true"][role="textbox"],div.ProseMirror[contenteditable="true"],div[contenteditable="true"][aria-multiline="true"],textarea');
  const editorText = el => (el?.innerText ?? el?.value ?? '').trim();
  const send = () => document.querySelector('button[data-testid="send-button"],button[aria-label="Send prompt"],button[aria-label^="Send" i]');
  // Both the classic and the current search-unit based conversation DOM.
  const roleUnits = role => {
    const old=[...document.querySelectorAll(`[data-message-author-role="${role}"]`)];
    if(old.length)return old;
    return [...document.querySelectorAll(`[data-conversation-role="${role}"]`)]
      .map(label=>label.closest('[data-chatgpt-search-unit-key],[data-content-search-unit-key]') || label.parentElement)
      .filter(Boolean);
  };
  const messages = () => roleUnits('assistant');
  const userMessages = () => {
    const modern=roleUnits('user');
    if(modern.length)return modern.length;
    // Current ChatGPT UI labels user turns with an unannotated "You said:" H4.
    // Count those headings only; do not infer from arbitrary text or CSS classes.
    // Search-unit turns do not consistently carry either turn-key attribute.
    // The previous ancestor requirement silently returned zero for valid turns.
    return [...document.querySelectorAll('h4')].filter(el =>
      el.textContent?.trim()==='You said:'
    ).length;
  };
  const latestMessage = () => messages().at(-1);
  const latestText = () => {
    const m=latestMessage();
    if(!m)return '';
    return m.innerText || m.textContent || '';
  };
  const signature = () => `${messages().length}:${latestText()}`;
  const latestTurnComplete = () => {
    const m=latestMessage();
    if(!m)return false;
    const turn=m.closest('[data-talvt-turn-state]');
    return turn?.getAttribute('data-talvt-turn-state')==='complete';
  };
  const hasStopMarker = marker => {
    const m=latestMessage(), target=(marker||'').trim();
    if(!m||!target)return false;
    const clean=s=>(s||'').replace(/[\u200b-\u200d\ufeff]/g,'').trim();
    const lineMatch=s=>clean(s).replace(/\r\n?/g,'\n').split('\n').some(line=>clean(line)===target);
    // innerText retains visual line breaks, unlike textContent.
    if(lineMatch(m.innerText)||lineMatch(m.textContent))return true;
    // Markdown paragraphs and other blocks can be flattened together by textContent.
    // Match the complete content of an individual rendered block or text node.
    const blocks=m.querySelectorAll('p,pre,code,li,blockquote,h1,h2,h3,h4,h5,h6');
    for(const el of blocks)if(lineMatch(el.innerText)||lineMatch(el.textContent))return true;
    const walker=document.createTreeWalker(m,NodeFilter.SHOW_TEXT);
    while(walker.nextNode())if(lineMatch(walker.currentNode.nodeValue))return true;
    return false;
  };
  const visible = e => !!e && e.getBoundingClientRect().width > 0 && e.getBoundingClientRect().height > 0;
  // The favicon Traffic Light owns the working/ready signal.  This script
  // consumes its published state rather than independently scanning controls.
  const isBusy = () => document.documentElement.dataset.plTrafficWorking === 'true';
  let host, root, toggle, panel, statusNode, elapsedNode, runButton, active=null, settings={...defaults}, lastPage=location.href, terminalStatus='Ready';
  function updateElapsed(session=active) {
    if(!elapsedNode || !session)return;
    const minutes=Math.floor(Math.max(0,Date.now()-session.startedAt)/60000);
    elapsedNode.textContent=`Elapsed: ${minutes} min`;
  }
  function status(s) {if(statusNode) statusNode.textContent=s; if(toggle) toggle.title=`Auto-Continue: ${s}`;}
  function stop(s='Stopped') {terminalStatus=s;if(active){updateElapsed(active);active.cancelled=true;active=null;}if(runButton)runButton.textContent='Run';status(s);}
  function stillActive(s) {if(active!==s||s.cancelled)return false;if(location.href!==s.url){stop('Conversation changed');return false;}return true;}
  function expired(s) {return Date.now()>=s.deadline;}
  function fill(el,value) {
    el.focus();
    if(el instanceof HTMLTextAreaElement || el instanceof HTMLInputElement) {
      const proto=el instanceof HTMLTextAreaElement?HTMLTextAreaElement.prototype:HTMLInputElement.prototype;
      Object.getOwnPropertyDescriptor(proto,'value').set.call(el,value);
      el.dispatchEvent(new InputEvent('input',{bubbles:true,inputType:'insertText',data:value}));
    } else {
      const selection=window.getSelection(),range=document.createRange();range.selectNodeContents(el);selection.removeAllRanges();selection.addRange(range);
      document.execCommand('insertText',false,value);
      el.dispatchEvent(new InputEvent('input',{bubbles:true,inputType:'insertText',data:value}));
    }
  }
  // Do not count an unchanged, preexisting assistant message as a new response.
  async function waitForIdle(s, baseline=null, baselineUsers=null) {
    let previous='',stable=0,observedBusy=false;
    const startingAssistants=messages().length;
    const requireNewResponse=baseline!==null;
    while(stillActive(s)) {
      if(expired(s)) {stop('Session timeout');return false;}
      const busy=isBusy(), sig=signature();
      if(busy) observedBusy=true;
      if(baselineUsers!==null && userMessages()>baselineUsers+1) {
        stop('Manual message detected');return false;
      }
      // Do not mistake an old assistant response (or a changing composer)
      // for the response to the continuation prompt we just submitted.
      const newAssistant=messages().length>startingAssistants ||
        (requireNewResponse && sig!==baseline && userMessages()>baselineUsers);
      const eligible=!requireNewResponse || newAssistant;
      if(eligible && !busy && sig===previous)stable++;else stable=0;
      previous=sig;
      if(eligible && stable>=7 && !busy)return true;
      await delay(500);
    }
    return false;
  }
  async function waitForReply(s, beforeUsers, beforeAssistants, beforeSignature) {
    let previous='',stable=0,seenResponse=false,seenBusy=false,loops=0;

    while(stillActive(s)) {
      if(expired(s)){stop('Session timeout');return false;}
      const users=userMessages(), busy=isBusy(), sig=signature();
      // Ambiguous DOM evidence is not proof of a failed submission. Never resend.
      if(++loops%4===0)status(`Running ${s.currentCycle || 0} / ${s.settings.cycles} · sent:${users>beforeUsers?'Y':'N'} · reply:${seenResponse?'Y':'N'} · busy:${busy?'Y':'N'} · assistants:${messages().length-beforeAssistants>=0?'+':''}${messages().length-beforeAssistants} · changed:${sig!==beforeSignature?'Y':'N'} · stable:${stable}`);
      if(users>beforeUsers+1){stop('Manual message detected');return false;}
      // Wait for the sent prompt to enter the conversation. The assistant
      // element count is not reliable in ChatGPT's virtualized message DOM.
      const sent=users>beforeUsers;
      if(busy)seenBusy=true;
      // A new assistant turn is stronger evidence than unreliable user-heading counts.
      // Never retry submission: accept an observed reply even when the user DOM is uncountable.
      const assistantChanged=messages().length>beforeAssistants || sig!==beforeSignature;
      if(assistantChanged && (sent || seenBusy || messages().length>beforeAssistants))seenResponse=true;
      if(seenResponse && !busy && sig===previous && (!latestMessage()?.closest('[data-talvt-turn-state]') || latestTurnComplete()))stable++;else stable=0;
      previous=sig;
      if(stable>=7 && (seenBusy || sent || messages().length>beforeAssistants))return true;
      await delay(500);
    }
    return false;
  }
  async function execute(s) {
    status('Waiting for ChatGPT');
    if(!await waitForIdle(s))return;
    // Pre-existing assistant messages (including setup instructions) cannot stop a cycle.
    for(let i=0;i<s.settings.cycles && stillActive(s);i++) {
      if(expired(s)){stop('Session timeout');return;}
      const e=editor();if(!e||editorText(e)){stop('Composer unavailable or not empty');return;}
      const before=signature(), beforeUsers=userMessages(), beforeAssistants=messages().length;
      fill(e,s.settings.prompt);
      await delay(350);
      if(!stillActive(s))return;
      const b=send();if(!b||b.disabled||b.getAttribute('aria-disabled')==='true'){stop('Send unavailable');return;}
      s.currentCycle=i+1;b.click();status(`Running ${i+1} / ${s.settings.cycles}`);
      // Wait for a genuinely new assistant turn, not a transient old message.
      if(!await waitForReply(s,beforeUsers,beforeAssistants,before))return;
      if(!stillActive(s))return;
      status(`Completed ${i+1} / ${s.settings.cycles}`);
      if(hasStopMarker(s.settings.stop)) {stop('Stop string detected');return;}
    }
    if(active===s)stop('All cycles completed');
  }
  function position() {
    if(!host)return;
    const e=editor();
    if(!e){host.style.display='none';return;}
    const composer=e.closest('form')||e.closest('[data-testid="composer"]')||e.parentElement;
    const r=composer?.getBoundingClientRect();if(!r?.width||!r?.height){host.style.display='none';return;}
    host.style.display='block';
    // Separate overlay, never occupies the composer layout or shrinks its input.
    const x=Math.max(4,r.left-40), y=Math.max(4,r.bottom-39);
    host.style.left=`${x}px`;host.style.top=`${y}px`;
    if(!panel.hidden) {panel.style.left='0px';panel.style.bottom='43px';}
  }
  function mount() {
    if(!document.body||host)return;
    host=document.createElement('div');host.id='pl-autocontinue-host';
    host.style.cssText='position:fixed;z-index:2147483640;width:34px;height:34px;pointer-events:none';
    root=host.attachShadow({mode:'closed'});
    root.innerHTML=`<style>
      *{box-sizing:border-box}button,input,textarea{font:inherit}button{cursor:pointer}
      #toggle{pointer-events:auto;width:34px;height:34px;border-radius:50%;border:1px solid #8887;background:var(--main-surface-primary,#fff);color:var(--text-primary,#222);font:24px system-ui;display:grid;place-items:center}
      #toggle:hover{background:var(--surface-hover,#ddd)}
      #panel{pointer-events:auto;position:absolute;width:min(340px,calc(100vw - 20px));max-height:75vh;overflow:auto;background:var(--main-surface-primary,#fff);color:var(--text-primary,#222);border:1px solid #8887;border-radius:14px;padding:14px;box-shadow:0 8px 28px #0004;font:13px system-ui}
      [hidden]{display:none!important}.heading{display:flex;justify-content:space-between;align-items:center;font-size:16px;font-weight:700}
      .close{background:none;border:0;color:inherit;font-size:20px}label{display:block;margin:10px 0 5px;font-weight:600}
      textarea,input{display:block;width:100%;margin-top:5px;padding:7px;border:1px solid #8887;border-radius:7px;background:var(--main-surface-primary,#fff);color:inherit}
      .fields{display:grid;grid-template-columns:1fr 1fr;gap:10px}.actions{display:flex;gap:8px;margin:12px 0}.actions button{flex:1;border:1px solid #8887;border-radius:8px;padding:8px}.run{background:#2563eb;color:white}.status{font-size:12px}small{opacity:.7}
    </style><button id="toggle" type="button" aria-label="Auto-Continue" title="Auto-Continue">↻</button>
    <section id="panel" hidden><div class="heading">Auto-Continue <button class="close" type="button" aria-label="Close panel">×</button></div>
    <label>Continuation prompt<textarea id="prompt" rows="5"></textarea></label>
    <div class="fields"><label>Cycles<input id="cycles" type="number" min="1" max="1000"></label><label>Timeout (minutes)<input id="minutes" type="number" min="1" max="10080"></label></div>
    <label>Stop string<input id="stop" type="text"></label><div class="status" id="status" role="status">Ready</div><div class="status" id="elapsed">Elapsed: 0 min</div>
    <div class="actions"><button class="run" id="run" type="button">Run</button><button id="cancel" type="button">Cancel loop</button></div>
    <small>Keep this ChatGPT tab open without refreshing or changing conversations.</small></section>`;
    document.body.appendChild(host);
    toggle=root.getElementById('toggle');panel=root.getElementById('panel');statusNode=root.getElementById('status');elapsedNode=root.getElementById('elapsed');runButton=root.getElementById('run');
    const fields=['prompt','cycles','minutes','stop'];
    const populate=()=>fields.forEach(k=>root.getElementById(k).value=settings[k]);
    populate();
    chrome.storage.local.get(KEY).then(result=>{settings={...defaults,...(result[KEY]||{})};if(!active)populate();});
    toggle.addEventListener('click',()=>{panel.hidden=!panel.hidden;position();});
    root.querySelector('.close').addEventListener('click',()=>panel.hidden=true);
    root.getElementById('cancel').addEventListener('click',()=>stop());
    runButton.addEventListener('click',async()=>{
      if(active)return;
      const c={};fields.forEach(k=>c[k]=root.getElementById(k).value);
      c.cycles=Number(c.cycles);c.minutes=Number(c.minutes);
      if(!c.prompt.trim()||!Number.isInteger(c.cycles)||c.cycles<1||c.cycles>1000||!Number.isFinite(c.minutes)||c.minutes<=0){status('Check prompt, cycles, and timeout');return;}
      settings=c;await chrome.storage.local.set({[KEY]:c});
      const s={settings:{...c},url:location.href,startedAt:Date.now(),deadline:0,cancelled:false};s.deadline=s.startedAt+c.minutes*60000;active=s;updateElapsed(s);
      terminalStatus='Running';runButton.textContent='Running';execute(s);
    });
    position();
    setInterval(()=>{if(active&&location.href!==active.url)stop('Conversation changed');if(!active && statusNode && statusNode.textContent!==terminalStatus)status(terminalStatus);updateElapsed();position();},650);
  }
  if(document.readyState==='loading')document.addEventListener('DOMContentLoaded',mount,{once:true});else mount();
})();
