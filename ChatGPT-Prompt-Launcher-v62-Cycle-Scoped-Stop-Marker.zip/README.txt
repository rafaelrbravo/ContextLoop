ChatGPT Prompt Launcher

Prompt buttons appear at the top of ChatGPT's left sidebar.
Click normally to launch and auto-submit the prompt in the current tab.
Ctrl-click or middle-click uses the browser's native new-tab behavior.

Each prompt has an HSV hue setting. Its ChatGPT tab favicon uses that hue:
faded while working, full color when ready/awaiting attention. Tabs not associated with a saved prompt use black with a white border, fading the black fill while working.
Circle = Chat; square = Work.

Click the extension toolbar icon to open settings.
